# Sistema-de-Empleados-Employees-system
En este proyecto es un sistema de reporte de empleados, donde podemos ingresar los datos de empleado planilla o contratados, como es en el caso de estudios, afp ,pago por horas, etc, realizado en java (Netbeans).
Version English:
this project is a system report employees, you can add datas of Payroll employee or Hiring employee, datas such as studyings, pay per hour, afp, etc.all this project was made in Java (Netbeans).
NOTA IMPORTANTE: en la carpeta PROYECTO FINAL se encuentra toda la programción de Sistema de Empleados
